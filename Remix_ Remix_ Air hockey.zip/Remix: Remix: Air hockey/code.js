var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// outer boundary.
var line1 = createSprite(397, 396, 5, 792);
line1.shapeColor = ("white");

var line2= createSprite(396, 2, 791, 5);
line2.shapeColor = ("white");

var line3 = createSprite(3, 3, 5, 794);
line3.shapeColor = ("white");

var line4 = createSprite(1, 398, 791, 5);
line4.shapeColor = ("white");

//inner boundary.
var line5 = createSprite(384, 390, 5, 792);
line5.shapeColor = ("white");

var line6 = createSprite(390, 20, 791, 5);
line6.shapeColor = ("white");

var line7 = createSprite(16, 5, 5, 794);
line7.shapeColor = ("white");

var line8 = createSprite(4, 384, 791, 5);
line8.shapeColor = ("white");

//middle line
var line9 = createSprite(3, 148, 791, 5);
line9.shapeColor = ("white");

var line10 = createSprite(1, 248, 791, 5);
line10.shapeColor = ("white");

//make two goal area's
var goal1 = createSprite(200, 28, 100, 20);
goal1.shapeColor =("yellow");
var goal2 = createSprite(200, 372, 100, 20);
goal2.shapeColor =("yellow");

//create objects and giving them colours
var striker = createSprite(200, 200, 10, 10);
striker.shapeColor =("white");

var playerMallet = createSprite(200, 50, 50, 10);
playerMallet.shapeColor =("black");

//make a computerMallet
var computerMallet = createSprite(200, 350, 50, 10);
computerMallet.shapeColor =("black");

var gamestate = "serve";
var compScore = 0;
var playerScore = 0;

function draw() {
  //clear the screen
  background("green");
  //giving control's to move the striker
  if (gamestate === "serve") {
    textSize(30);
    fill("grey");
    text("press space to serve", 65, 171);
  }
  //making computer and player score
  text(compScore,30, 240);
  text(playerScore,30,180);
  
  createEdgeSprites();
  
// make the player Paddle move with the arrow key
if (keyDown("up")) {
if (playerMallet.y>25) {
playerMallet.y = playerMallet.y- 10;
    }
}
if (keyDown("down")) {
if (playerMallet.y<120) {
playerMallet.y = playerMallet.y+10;
 }
     
  }
if (keyDown("left")) {
playerMallet.x = playerMallet.x-10;
     
}
   
if (keyDown("right")) {
playerMallet.x = playerMallet.x+10;
}
   
//AI for the computer Paddle
//Make it move with the striker's y position
computerMallet.x = striker.x;
 
//draw line at the centre
for (var i = 5; i < 400; i=i+20) {
line(i, 200, i+10, 200);
}
 

//striker is bounceoff with lines, playerPaddle and computerPaddle
striker.bounceOff(line5);
striker.bounceOff(line6);
striker.bounceOff(line7);
striker.bounceOff(line8);
striker.bounceOff(playerMallet);
striker.bounceOff(computerMallet);

//playerMallet is bounceoff with lines
playerMallet.bounceOff(line5);
playerMallet.bounceOff(line6);
playerMallet.bounceOff(line7);
playerMallet.bounceOff(line9);

//computerMallet is bounceoff with lines
computerMallet.bounceOff(line5);
computerMallet.bounceOff(line7);
computerMallet.bounceOff(line8);
computerMallet.bounceOff(line10);

if (keyDown("space") && gamestate === "serve") {
  serve();
  gamestate = "play";
}

//score
if (striker.isTouching(goal1) || striker.isTouching(goal2)) {

if (striker.isTouching(goal1)) {
 compScore = compScore + 1;
  }
if (striker.isTouching(goal2)) {
  playerScore = playerScore + 1;
  }
  reset();
  gamestate = "serve";
}
//giving control after the score reaching 5 press 'r'
if (playerScore === 5 || compScore === 5){
  gamestate = "end";
  textSize(25);
  fill("yellow");
  fill("light red");
  text("GAME OVER", 150, 172);
  textSize(25);
  fill("yellow"); 
  text("press 'r' to restart",151, 190);
  
//x and y for playerMallet
   playerMallet.x = 200; 
  playerMallet.y = 50;
}
//end state
if (keyDown('r') && gamestate === "end") {
  gamestate = "serve";
  compScore =0;
  playerScore =0;
}

 drawSprites();
 
}


function serve() {
     striker.velocityX = 3;
     striker.velocityY = 4;
 }
   
function reset() {
    striker.x = 200;
    striker.y = 200;
    striker.velocityX = 0;
    striker.velocityY = 0;
  }   

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
